import json
import asyncio
from telegram import Bot
from telegram.constants import ParseMode
from handlers import constants


def lambda_handler(event, context):
    result = asyncio.run(async_handler(event, context))
    body = json.loads(event['body'])
    return {
        "statusCode": 200,
        "body": json.dump(body)
    }


async def async_handler(event, context):
    bot = Bot(token=constants.TELEGRAM_TOKEN)
    async with bot:
        await bot.send_message(chat_id=constants.GROUP_CHAT_ID,
                               text="", parse_mode=ParseMode.MARKDOWN)
    return constants.GROUP_CHAT_ID
